=== Wordpress Bangla Pack ===
Contributor: Third Sailor
Tags: wordpress bangla tranlator, localized wordpress in bangla, bangla wordpress, wpbangla, bangla plugin
Requires at least: 2.2
Tested up to: 4.1.1
License: GNU (General Public License) v3.0
License URI: http://www.gnu.org/copyleft/gpl.html

Wordpress Bangla is a simple, smart & easy plugin by which you can localize your Wordpress site in Bangla.

== Description ==
Wordpress Bangla Pack is a simple, smart & easy plugin by which you can localize your Wordpress site in Bangla. It means that your whole site will appear in Bangla. Here I have used the best translation of each phrases & sentences to provide the best plugin to its users. If you ever think about a plugin to translate your Wordpress site in Bangla, you should not choose any other way except Wordpress Bangla Pack.
Happy Blogging!!!

== Installation ==
It\'s very easy to install this plugin. You have to install just like other plugins. But for your help, I\'ve stated the method below:

1. Firstly you have to download the latest .zip file
2. Go to http://yoursite.com/wp-admin/plugin-install.php
3. Choose Wordpress Bangla.zip
4. Upload it.
5. After uploading, just install it.

Enjoy the best plugin to translate your Wordpress site.