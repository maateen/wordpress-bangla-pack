=== Wordpress Bangla Pack ===<br />
Contributor: Third Sailor<br />
Tags: wordpress bangla tranlator, localized wordpress in bangla, bangla wordpress, wpbangla, bangla plugin<br />
Requires at least: 2.2<br />
Tested up to: 4.1.1<br />
License: GNU (General Public License) v3.0<br />
License URI: http://www.gnu.org/copyleft/gpl.html<br />
<br />
Wordpress Bangla is a simple, smart & easy plugin by which you can localize your Wordpress site in Bangla.<br />
<br />
== Description ==<br />
Wordpress Bangla Pack is a simple, smart & easy plugin by which you can localize your Wordpress site in Bangla. It means that your whole site will appear in Bangla. Here I have used the best translation of each phrases & sentences to provide the best plugin to its users. If you ever think about a plugin to translate your Wordpress site in Bangla, you should not choose any other way except Wordpress Bangla Pack.<br />
Happy Blogging!!!<br />
<br />
== Installation ==<br />
It\'s very easy to install this plugin. You have to install just like other plugins. But for your help, I\'ve stated the method below:<br />
<br />
1. Firstly you have to download the latest .zip file<br />
2. Go to http://yoursite.com/wp-admin/plugin-install.php<br />
3. Choose Wordpress Bangla.zip<br />
4. Upload it.<br />
5. After uploading, just install it.<br />
<br />
Enjoy the best plugin to translate your Wordpress site.<br />
